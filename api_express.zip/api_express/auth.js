const jwt = require('jsonwebtoken');
const SECRET_KEY = 'suaChaveSecreta'; // Substitua por uma chave segura em um ambiente de produção

function verificarToken(req, res, next) {
    const token = req.header('Authorization');
    const words = token.split(" ");
  
    jwt.verify(words[1], SECRET_KEY, (err, user) => {
      if (err) {
        return res.status(403).json({ message: 'Falha na autenticação do token' });
      }
  
      req.user = user;
      next();
    });
}

module.exports = {
    verificarToken
};