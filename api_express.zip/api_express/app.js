const { verificarToken } = require('./auth');
const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;

app.use(bodyParser.json());

// Rota de login
app.post('/login', (req, res) => {
  const { username, password } = req.body;

  if (username === 'usuario' && password === 'senha') {
    const token = jwt.sign({ username }, SECRET_KEY, { expiresIn: '300s' });
    res.json({ token });
  } else {
    res.status(401).json({ message: 'Credenciais inválidas' });
  }
});
// Todas as rotas abaixo desta linha requerem autenticação
// app.use(verificarToken);

// Rota protegida
app.get('/protegido',verificarToken, (req, res) => {
  res.json({ message: 'Rota protegida acessada com sucesso', user: req.user });
});

app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});

