package packageQuestao1;

public interface iEstudante {
    boolean estaAprovado();
    String getNome();
    String getNivel();
}
