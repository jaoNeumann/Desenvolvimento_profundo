package packageQuestao1;

import java.util.List;

public class FabricaEstudanteMestrado implements iFabricaEstudantes{

    private String nome;
    private List<String> conceitos;

    public FabricaEstudanteMestrado(String nome, List<String> conceitos) {
        this.nome = nome;
        this.conceitos = conceitos;
    }

    @Override
    public iEstudante criarEstudante() {
        return new EstudanteMestrado(nome, conceitos);
    }
    
}
