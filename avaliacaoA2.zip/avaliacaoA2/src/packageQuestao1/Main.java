package packageQuestao1;

import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        // Criando estudante de esnsino Médio e injetando os valores no construtor
        List<Double> notasMedio = Arrays.asList(9.5, 1.0, 9.0, 9.0);
        FabricaEstudanteMedio fabricaMedio = new FabricaEstudanteMedio("Maria", notasMedio);
        iEstudante estudanteMedio = fabricaMedio.criarEstudante();

        // Criando estudante de Bacharelado e injetando os valores no construtor
        List<Double> notasBacharelado = Arrays.asList(8.5, 7.0, 9.0, 9.0); 
        FabricaEstudanteBacharelado fabricaBacharelado = new FabricaEstudanteBacharelado("João", notasBacharelado);
        iEstudante estudanteBacharelado = fabricaBacharelado.criarEstudante();

        // Criando estudante de Mestrado e injetando os valores no construtor
        List<String> conceitos = Arrays.asList("A", "A", "A", "A");
        FabricaEstudanteMestrado fabricaMestrado = new FabricaEstudanteMestrado("L. Escobar", conceitos);
        iEstudante estudanteMestrado = fabricaMestrado.criarEstudante();


        // Estudante do Médio
        if (estudanteMedio.estaAprovado() == false) {
            System.out.println("O estudante " + estudanteMedio.getNome() + " está de recuperação :(");
        }else{
            System.out.println("O estudante " + estudanteMedio.getNome() + " está aprovado :)");
        } 

        // Estudante do bacharelado
        if (estudanteBacharelado.estaAprovado() == false) {
            System.out.println("O estudante " + estudanteBacharelado.getNome() + " deve fazer a prova final :(");
        }else{
            System.out.println("O estudante " + estudanteBacharelado.getNome() + " está aprovado :)");
        } 
        
        // Estudante do Mestrado
        if (estudanteMestrado.estaAprovado() == false) {
            System.out.println("O estudante " + estudanteMestrado.getNome() + " está fora do mestrado :(");
        }else{
            System.out.println("O estudante " + estudanteMestrado.getNome() + " está aprovado :)");
        }
    }
}
