package packageQuestao1;

import java.util.List;

public class EstudanteBacharelado implements iEstudante{

    private String nome;
    private List<Double> notas;

    public EstudanteBacharelado(String nome, List<Double> notas) {
        this.nome = nome;
        this.notas = notas;
    }

    @Override
    public boolean estaAprovado() {
        for (Double nota : notas) {
            if (nota < 6.0) {
                return false;
            }
        }
        return true;
    }

    @Override
    public String getNome() {
        return nome;
    }

    @Override
    public String getNivel() {
        return "Bacharelado";
    }
}