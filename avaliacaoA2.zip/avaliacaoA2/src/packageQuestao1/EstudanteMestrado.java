package packageQuestao1;

import java.util.List;

public class EstudanteMestrado implements iEstudante{

    private String nome;
    private List<String> conceitos;

    public EstudanteMestrado(String nome, List<String> conceitos) {
        this.nome = nome;
        this.conceitos = conceitos;
    }

    @Override
    public boolean estaAprovado() {
        for (String conceito : conceitos) {
            if (conceito.equals("D")) {
                return false;
            }
        }
        return true;
    }

    @Override
    public String getNome() {
        return nome;
    }

    @Override
    public String getNivel() {
        return "Mestrado";
    }
}