package packageQuestao1;

import java.util.List;

public class EstudanteMedio implements iEstudante {

    private String nome;
    private List<Double> notas;

    public EstudanteMedio(String nome, List<Double> notas) {
        this.nome = nome;
        this.notas = notas;
    }

    @Override
    public boolean estaAprovado() {
        double media = calcularMedia();
        return media > 7.0;
    }

    @Override
    public String getNome() {
        return nome;
    }

    @Override
    public String getNivel() {
        return "Médio";
    }

    private double calcularMedia() {
        double soma = 0.0;
        for (Double nota : notas) {
            soma += nota;
        }
        return soma / notas.size();
    }
}