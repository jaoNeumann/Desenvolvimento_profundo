package packageQuestao1;

import java.util.List;

public class FabricaEstudanteMedio implements iFabricaEstudantes{

    private String nome;
    private List<Double> notas;

    public FabricaEstudanteMedio(String nome, List<Double> notas) {
        this.nome = nome;
        this.notas = notas;
    }

    @Override
    public iEstudante criarEstudante() {
        return new EstudanteMedio(nome, notas);
    }
}
