package packageQuestao1;

public interface iFabricaEstudantes {
    iEstudante criarEstudante();
}
