package packageQuestao2;

public interface iFabricaUnidadeDeSaude {
    iUnidadeDeSaude criarUnidadeDeSaude();
}
