package packageQuestao2;

public interface iFabricaPaciente {
    iPaciente criarPaciente(String nome);
}
