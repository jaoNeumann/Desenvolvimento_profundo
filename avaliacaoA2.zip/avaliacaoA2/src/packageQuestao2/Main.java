package packageQuestao2;

public class Main {
    public static void main(String[] args) {
        Emergencia emergencia = new Emergencia();

        iUnidadeDeSaude uti = new UTI();
        iUnidadeDeSaude enfermaria = new Enfermaria();

        emergencia.adicionarObservador(uti);
        emergencia.adicionarObservador(enfermaria);

        iFabricaPaciente fabricaPaciente = new FabricaPaciente();
        iPaciente pacienteEmergencia = fabricaPaciente.criarPaciente("João");
        iPaciente pacienteConvencional = fabricaPaciente.criarPaciente("Maria");

        emergencia.admitirPaciente(pacienteEmergencia);
        emergencia.admitirPaciente(pacienteConvencional);
    }
}




