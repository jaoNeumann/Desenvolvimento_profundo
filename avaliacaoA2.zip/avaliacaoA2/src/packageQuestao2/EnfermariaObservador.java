package packageQuestao2;

public class EnfermariaObservador implements iUnidadeDeSaude {

    @Override
    public void notificar(iPaciente paciente) {
        System.out.println("Paciente convencional " + paciente.getNome() + " admitido na enfermaria.");
    }
}