package packageQuestao2;

public class FabricaPaciente implements iFabricaPaciente {
    @Override
    public iPaciente criarPaciente(String nome) {
        return new Paciente(nome);
    }
}