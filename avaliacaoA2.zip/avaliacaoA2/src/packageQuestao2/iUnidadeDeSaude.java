package packageQuestao2;

public interface iUnidadeDeSaude {
    void notificar(iPaciente paciente);
}
