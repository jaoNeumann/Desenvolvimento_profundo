package packageQuestao2;

import java.util.ArrayList;
import java.util.List;

public class Emergencia {

    private List<iUnidadeDeSaude> observadores = new ArrayList<>();

    public void adicionarObservador(iUnidadeDeSaude observador) {
        observadores.add(observador);
    }

    public void removerObservador(iUnidadeDeSaude observador) {
        observadores.remove(observador);
    }

    public void admitirPaciente(iPaciente paciente) {
        for (iUnidadeDeSaude observador : observadores) {
            observador.notificar(paciente);
        }
    }
}
