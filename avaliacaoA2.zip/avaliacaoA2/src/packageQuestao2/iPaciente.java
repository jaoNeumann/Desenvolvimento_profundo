package packageQuestao2;

public interface iPaciente {
    String getNome();
}
