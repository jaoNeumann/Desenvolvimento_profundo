package packageQuestao2;

public class Paciente implements iPaciente {
    private String nome;

    public Paciente(String nome) {
        this.nome = nome;
    }

    @Override
    public String getNome() {
        return nome;
    }
}