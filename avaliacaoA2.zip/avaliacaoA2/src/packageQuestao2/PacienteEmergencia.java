package packageQuestao2;

public class PacienteEmergencia implements iPaciente {

    private String nome;

    public PacienteEmergencia(String nome) {
        this.nome = nome;
    }

    @Override
    public String getNome() {
        return nome;
    }
}