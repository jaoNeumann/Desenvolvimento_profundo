package packageQuestao2;

public class PacienteConvencional implements iPaciente {

    private String nome;

    public PacienteConvencional(String nome) {
        this.nome = nome;
    }

    @Override
    public String getNome() {
        return nome;
    }
}