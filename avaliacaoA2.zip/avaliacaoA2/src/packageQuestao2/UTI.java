package packageQuestao2;

public class UTI implements iUnidadeDeSaude {
    
    @Override
    public void notificar(iPaciente paciente) {
        System.out.println("Paciente " + paciente.getNome() + " admitido na UTI.");
    }
}
