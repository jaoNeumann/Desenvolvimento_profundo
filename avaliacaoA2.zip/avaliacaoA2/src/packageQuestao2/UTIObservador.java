package packageQuestao2;

public class UTIObservador implements iUnidadeDeSaude {

    @Override
    public void notificar(iPaciente paciente) {
        System.out.println("Paciente de emergência " + paciente.getNome() + " admitido na UTI.");
    }
}