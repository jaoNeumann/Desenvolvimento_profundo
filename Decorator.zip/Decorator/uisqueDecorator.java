package Decorator;

public class uisqueDecorator extends ABSDecorator{

	public uisqueDecorator(IBebida bebida) {
		super(bebida);
	}

	@Override
	public String Descricao() {
		return bebida.Descricao() + " com uísque";
	}

	@Override
	public double Preco() {
		return bebida.Preco() + 30;
	}
	
}
