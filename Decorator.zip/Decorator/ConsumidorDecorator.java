package Decorator;

public class ConsumidorDecorator {

	public static void main(String[] args) {
		// Criar o componente concreto (base)
		IBebida cafe = new Cafe();
		System.out.println(" Pedido 1 " + cafe.Descricao() + " Preço: " + cafe.Preco());
		
		cafe = new uisqueDecorator(cafe);
		System.out.println(" Pedido 2 " + cafe.Descricao() + " Preço: " + cafe.Preco());
		
		cafe = new leiteDecorator(cafe);
		System.out.println(" Pedido 3 " + cafe.Descricao() + " Preço: " + cafe.Preco());
		
		cafe = new acucarDecorator(cafe);
		System.out.println(" Pedido 4 " + cafe.Descricao() + " Preço: " + cafe.Preco());
		

	}

}
