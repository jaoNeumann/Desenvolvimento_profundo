package Decorator;

public class leiteDecorator extends ABSDecorator{

	public leiteDecorator(IBebida bebida) {
		super(bebida);
	}

	@Override
	public String Descricao() {
		return bebida.Descricao() + " com leite";
	}

	@Override
	public double Preco() {
		return bebida.Preco() + 0.5;
	}

}
