package Decorator;

public class acucarDecorator extends ABSDecorator{

	public acucarDecorator(IBebida bebida) {
		super(bebida);
	}

	@Override
	public String Descricao() {
		return bebida.Descricao() + " com açucar";
	}

	@Override
	public double Preco() {
		return bebida.Preco() + 0.1;
	}
	

}
