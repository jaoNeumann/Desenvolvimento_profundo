package Decorator;

public abstract class ABSDecorator implements IBebida{
	protected IBebida bebida;
	public ABSDecorator(IBebida bebida) {
		this.bebida = bebida;
	}
}
