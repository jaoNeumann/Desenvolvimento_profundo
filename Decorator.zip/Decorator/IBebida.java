package Decorator;

public interface IBebida {
	public String Descricao();
	public double Preco();
}
