package Atv1;

public class FabricaPentagono implements iFabricasFormas{
	
	@Override
	public iForma criaForma() {
		return new Pentagono();
	}
}
