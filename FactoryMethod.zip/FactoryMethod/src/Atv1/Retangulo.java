package Atv1;

public class Retangulo implements iForma {
	
	@Override
	public void desenhar() {
		System.out.println("Desenhando um retangulo");
	}
}
