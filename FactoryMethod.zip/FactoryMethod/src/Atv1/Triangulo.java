package Atv1;

public class Triangulo implements iForma{

	@Override
	public void desenhar() {
		System.out.println("Desenhando um triangulo");
	}
}
