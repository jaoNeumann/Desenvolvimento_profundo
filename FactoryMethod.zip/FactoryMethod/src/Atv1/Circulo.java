package Atv1;

public class Circulo implements iForma {
	
	@Override
	public void desenhar() {
		System.out.println("Desenhando um circulo");
	}
}
