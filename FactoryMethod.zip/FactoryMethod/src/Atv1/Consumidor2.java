package Atv1;

public class Consumidor2 {
	public static void main(String[] args) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
		
		String classe_para_instanciar;
		classe_para_instanciar = "Atv1.Circulo";		
		iForma x = (iForma) Class.forName(classe_para_instanciar).newInstance();
		x.desenhar();
	
	    try {
	        Class<?> clazz = Class.forName(classeParaInstanciar);
	        Constructor<?> constructor = clazz.getDeclaredConstructor();
	        iForma x = (iForma) constructor.newInstance();
	        x.desenhar();
	    } catch (ClassNotFoundException e) {
	        // Lida com a exceção de classe não encontrada
	    } catch (NoSuchMethodException e) {
	        // Lida com a exceção de construtor não encontrado
	    } catch (InstantiationException e) {
	        // Lida com a exceção de instância não pode ser criada
	    } catch (IllegalAccessException e) {
	        // Lida com a exceção de acesso ilegal
	    } catch (InvocationTargetException e) {
	        // Lida com exceção de invocação do construtor ou método
	    }
	}
	
	
	}
}