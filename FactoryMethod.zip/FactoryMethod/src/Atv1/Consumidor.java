package Atv1;

public class Consumidor {
	public static void main(String[] args) {
		
		
		Desenhista d = new Desenhista();
		
		d.desenhe(TipoFigura.PENTAGONO);
	}
}