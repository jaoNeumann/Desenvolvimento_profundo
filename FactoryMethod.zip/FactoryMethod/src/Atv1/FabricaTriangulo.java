package Atv1;

public class FabricaTriangulo implements iFabricasFormas{

	@Override
	public iForma criaForma() {
		return new Triangulo();
	}
	
}
