package Atv1;

public class FabricaRetangulo implements iFabricasFormas{
	
	@Override
	public iForma criaForma() {
		return new Retangulo();
	}
}
