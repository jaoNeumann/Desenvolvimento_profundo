package Atv1;

public enum TipoFigura {
	CIRCULO("Circulo"),
	TRIANGULO("Triangulo"),
	RETANGULO("Retangulo"),
	PENTAGONO("Pentagono");
	
	private String descricao;
	
	TipoFigura(String descricao){
		this.descricao = descricao;
	}
	
	public String getDescricao() {
		return descricao;
	}
}
