package Atv1;

public class Pentagono implements iForma{
	
	@Override
	public void desenhar() {
		System.out.println("Desenhando um pentagono");
	}
}
