package Atv1;

public class Desenhista {
	
	public void desenhe(TipoFigura figura) {
		switch (figura) {
			case CIRCULO: {
				//Cria um objeto Circulo() com assinatura iForma
				iFabricasFormas circuloFactory = new FabricaCirculo();
				iForma bolota = circuloFactory.criaForma();
				bolota.desenhar();
				break;
			}
			case TRIANGULO: {
				//Cria um objeto Triangulo() com assinatura iForma
				iFabricasFormas trinaguloFactory = new FabricaTriangulo();
				iForma piramide = trinaguloFactory.criaForma();
				piramide.desenhar();
				break;
			}
			case RETANGULO: {
				//Cria um objeto Retangulo() com assinatura iForma
				iFabricasFormas retaguloFactory = new FabricaRetangulo();
				iForma caixote = retaguloFactory.criaForma();
				caixote.desenhar();
				break;
			}
			case PENTAGONO: {
				//Cria um objeto Pentagono() com assinatura iForma
				iFabricasFormas pentagonoFactory = new FabricaPentagono();
				iForma bola_de_futebol = pentagonoFactory.criaForma();
				bola_de_futebol.desenhar();
				break;
			}
			default:{
				System.out.println("Apenas valores válidos");
			}
		}
	}
}