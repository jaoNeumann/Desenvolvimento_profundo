package Atv1;

public interface iFabricasFormas {
	iForma criaForma();
}
