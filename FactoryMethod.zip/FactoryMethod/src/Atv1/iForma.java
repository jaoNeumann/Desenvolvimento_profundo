package Atv1;

public interface iForma {
	void desenhar();
	
	
}
