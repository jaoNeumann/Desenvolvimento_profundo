package classes;

public interface Interfacee {
	
}
