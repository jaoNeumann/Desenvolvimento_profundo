package classes;

public class Transacao {
	public double ValorBruto;
	
	public double calcularValorLiquido() {
		return 12;
	}
}
