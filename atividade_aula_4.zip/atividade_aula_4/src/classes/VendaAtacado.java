package classes;

public class VendaAtacado extends Transacao{
	Transacao t = new Transacao();
	 
	public double Desconto;
	
	
}
