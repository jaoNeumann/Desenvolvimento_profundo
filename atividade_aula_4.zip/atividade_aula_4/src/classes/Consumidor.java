package classes;

public class Consumidor {
	public static void main(String[] args) {
		
	}
	
}
