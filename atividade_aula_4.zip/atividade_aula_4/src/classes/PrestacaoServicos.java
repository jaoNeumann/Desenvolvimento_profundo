package classes;

public class PrestacaoServicos extends Transacao{
	Transacao t = new Transacao();
	
	public double TaxaServicos;
	public double ValorLiquido = t.ValorBruto - (t.ValorBruto * TaxaServicos);
}
