package classes;

public class VendaVarejo extends Transacao{
	Transacao t = new Transacao();
	
	public double TaxaImposto;
	public double ValorLiquido = t.ValorBruto - (t.ValorBruto * TaxaImposto);
	
}
