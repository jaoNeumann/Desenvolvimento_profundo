package Observer;

public abstract class ABSObserver {
	protected Subject subject;
	public abstract void Update();
	
}
