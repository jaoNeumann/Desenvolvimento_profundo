package Observer;

public class concreteObserver extends ABSObserver{
	public concreteObserver(Subject subject) { //adicione uma fabrica abstrata
		this.subject = subject;
		this.subject.attach(this);
	}
	
	@Override
	public void Update() {
		// Lógica que reage à mudança de estado no objeto observado
		System.out.println("O observador foi notiicado. Novo estado do objeto: " + this.subject.getState());
	}	
}
