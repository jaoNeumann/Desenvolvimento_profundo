const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('aplicacao_1', 'root', 'positivo', {
  host: 'localhost',
  dialect: 'mysql',
});

module.exports = sequelize;
