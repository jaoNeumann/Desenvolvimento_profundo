const Product = require('../Models/product');

class ProductService {
  async createProduct(id, name, category, listPrice) {
    return Product.create({ id, name, category, listPrice });
  }

  async getProductById(id) {
    return Product.findOne({ where: { id } });
  }
  
  async getProducts() {
    return Product.findAll({ where: { id} });
  }
}
module.exports = new ProductService();
