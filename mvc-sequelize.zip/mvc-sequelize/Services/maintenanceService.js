const Maintenance = require('../Models/maintenance');

class MaintenanceService {
  async createMaintenance( id, data, description ) {
    return Maintenance.create({ id, data, description });
  }
}
module.exports = new MaintenanceService();
