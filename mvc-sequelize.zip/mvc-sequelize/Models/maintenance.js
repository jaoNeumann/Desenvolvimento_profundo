const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const Product = require('../Product');

const Maintenance = sequelize.define('Maintenance', {
    id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
        unique: true,
    },
    data: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    description: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    ProductId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'Product',
            key: 'id',
        },
    },
});

Maintenance.belongsTo(Product);
Maintenance.sync(); // Sincroniza o modelo com o banco de dados

module.exports = Maintenance;
