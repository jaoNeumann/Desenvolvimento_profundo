const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const Maintenance = require('../Maintenance');

const Product = sequelize.define('Product', {
    id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
        unique: true,
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    category: {
        type: DataTypes.STRING,
        allowNull: false,    
    },
    listPrice: {
        type: DataTypes.FLOAT,
        allowNull: false,
    },
});

Product.hasMany(Maintenance, { foreignKey: 'ProductId' });

Product.sync(); // Sincroniza o modelo com o banco de dados

module.exports = Product;
