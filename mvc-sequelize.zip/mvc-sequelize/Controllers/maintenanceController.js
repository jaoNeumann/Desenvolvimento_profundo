const maintenanceService = require('../Services/maintenanceService');
class maintenanceController {
    async createMaintenance(req, res) {
      const { id, data, description } = req.body;
  
      try {
        const newMaintenance = await maintenanceService.creatcreateMaintenanceeUser( id, data, description );
        res.status(201).json(newMaintenance);
      } catch (error) {
        console.error('Erro ao criar manuntenção:', error);
        res.status(500).json({ error: 'Ocorreu um erro durante a criação da manuntenção.' });
      }
    }
  
  }
  
  module.exports = new maintenanceController();
  