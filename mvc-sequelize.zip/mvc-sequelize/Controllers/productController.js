const productService = require('../Services/productService');
class ProductController {
    async createProduct(req, res) {
      const { id, name, category, listPrice } = req.body;
  
      try {
        const newProduct = await productService.createProduct(id, name, category, listPrice);
        res.status(201).json(newProduct);
      } catch (error) {
        console.error('Erro ao criar produto:', error);
        res.status(500).json({ error: 'Ocorreu um erro durante a criação do produto.' });
      }
    }
  
    async getProductById(req, res) {
      const { id } = req.params;
  
      try {
        const product = await productService.getProductById(id);
        res.status(200).json(product);
      } catch (error) {
        console.error('Erro ao buscar produto:', error);
        res.status(500).json({ error: 'Ocorreu um erro durante a busca do produto.' });
      }
    }

    async getProducts(req, res) {
    
        try {
          const product = await productService.getProducts();
          res.status(200).json(product);
        } catch (error) {
          console.error('Erro ao buscar produto:', error);
          res.status(500).json({ error: 'Ocorreu um erro durante a busca do produto.' });
        }
      }
  }
  
  module.exports = new ProductController();
  